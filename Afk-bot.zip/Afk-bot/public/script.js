
// Load bot status when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadBotStatus();
    
    // Auto-refresh every 30 seconds
    setInterval(loadBotStatus, 30000);
});

async function loadBotStatus() {
    try {
        const response = await fetch('/api/status');
        const data = await response.json();
        
        updateBotInfo(data);
        updateStatusIndicator(true);
    } catch (error) {
        console.error('Error loading bot status:', error);
        updateStatusIndicator(false);
    }
}

function updateBotInfo(data) {
    // Update bot information
    document.getElementById('server').textContent = data.server;
    document.getElementById('username').textContent = data.username;
    document.getElementById('version').textContent = data.version;
    document.getElementById('position').textContent = data.position;
    
    // Update feature statuses
    updateFeatureStatus('antiAfk', data.antiAfk);
    updateFeatureStatus('chatMessages', data.chatMessages);
    updateFeatureStatus('autoReconnect', data.autoReconnect);
}

function updateFeatureStatus(elementId, enabled) {
    const element = document.getElementById(elementId);
    element.textContent = enabled ? 'Enabled' : 'Disabled';
    element.className = `feature-status ${enabled ? 'status-enabled' : 'status-disabled'}`;
}

function updateStatusIndicator(isOnline) {
    const indicator = document.getElementById('statusIndicator');
    const dot = indicator.querySelector('.status-dot');
    const text = indicator.querySelector('span:last-child');
    
    if (isOnline) {
        dot.style.background = '#4CAF50';
        text.textContent = 'Bot Online';
    } else {
        dot.style.background = '#f44336';
        text.textContent = 'Connection Error';
    }
}

function refreshStatus() {
    const btn = event.target;
    const originalText = btn.innerHTML;
    
    btn.innerHTML = '🔄 Refreshing...';
    btn.disabled = true;
    
    loadBotStatus().finally(() => {
        btn.innerHTML = originalText;
        btn.disabled = false;
    });
}

// Add touch feedback for mobile
document.addEventListener('touchstart', function(e) {
    if (e.target.classList.contains('btn')) {
        e.target.style.transform = 'scale(0.98)';
    }
});

document.addEventListener('touchend', function(e) {
    if (e.target.classList.contains('btn')) {
        setTimeout(() => {
            e.target.style.transform = '';
        }, 100);
    }
});
